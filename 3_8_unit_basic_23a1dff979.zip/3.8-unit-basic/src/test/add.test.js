const add = require('../add.js');

test('add', () => {
  // 테스트 코드 작성!
  expect(add(1, 2)).toBe(3);
});
